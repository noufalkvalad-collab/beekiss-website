// Minimal JS: products, rendering, hash routing, WhatsApp link
const PRODUCTS = [
  {
    id: "stick",
    name: "Bee Kiss – Pure Forest Honey Stick",
    subtitle: "Single-use honey stick",
    priceText: "₹10",
    image: "assets/product-1.svg",
  },
  {
    id: "combo",
    name: "Bee Kiss – Honey Stick Combo Pack",
    subtitle: "Assorted stick pack",
    priceText: "From ₹95",
    image: "assets/product-2.svg",
  },
  {
    id: "bottle",
    name: "Bee Kiss – Pure Forest Honey (Bottle)",
    subtitle: "Premium glass bottle",
    priceText: "From ₹250",
    image: "assets/product-3.svg",
  },
  {
    id: "raw",
    name: "Bee Kiss – Raw Forest Honey",
    subtitle: "Unfiltered, raw honey",
    priceText: "Premium",
    image: "assets/product-4.svg",
  },
  {
    id: "gift",
    name: "Bee Kiss – Healthy Gift Pack",
    subtitle: "Gift edition curated set",
    priceText: "Gift Edition",
    image: "assets/product-5.svg",
  },
  {
    id: "trial",
    name: "Bee Kiss – Trial / Sample Pack",
    subtitle: "Trial size pack",
    priceText: "Trial Pack",
    image: "assets/product-6.svg",
  }
];

const DETAIL_SAMPLE_DESC = `വയനാടൻ വനങ്ങളിൽ നിന്ന് നേരിട്ട് ശേഖരിച്ച
മായം കലരാത്ത 100% ശുദ്ധമായ അസ്സൽ തേൻ.`; // sample description (Malayalam)

const BENEFITS = [
  { text: "🍯 100% Pure Forest Honey" },
  { text: "❌ No Sugar • No Chemicals" },
  { text: "⚡ Instant Natural Energy" },
  { text: "🎒 Travel Friendly" }
];

function el(selector){ return document.querySelector(selector) }

function renderCatalog(){
  const grid = el("#productGrid");
  grid.innerHTML = "";
  PRODUCTS.forEach(p=>{
    const card = document.createElement("article");
    card.className = "card";
    card.setAttribute("role","article");
    card.innerHTML = `
      <div class="card-img">
        <img src="${p.image}" alt="${p.name}" width="56" height="56">
      </div>
      <div class="card-meta">
        <h4 class="card-title">${p.name}</h4>
        <div class="card-sub">${p.subtitle}</div>
      </div>
      <div class="card-actions">
        <div class="price">${p.priceText}</div>
        <button class="view-btn" data-id="${p.id}">View →</button>
      </div>
    `;
    grid.appendChild(card);
  });

  // attach listeners
  grid.querySelectorAll(".view-btn").forEach(btn=>{
    btn.addEventListener("click", (e)=>{
      const id = btn.dataset.id;
      location.hash = `#product=${id}`;
    });
  });
}

function showSection(name){
  // simple show/hide
  ["catalog","about","productDetail"].forEach(k=>{
    const elk = document.getElementById(k);
    if(!elk) return;
    if(k === name) elk.classList.remove("hidden");
    else elk.classList.add("hidden");
  });
}

function showProductById(id){
  const p = PRODUCTS.find(x=>x.id === id);
  if(!p) {
    // fallback to catalog
    location.hash = "";
    return;
  }
  showSection("productDetail");
  // fill detail
  el("#detailImage").src = p.image;
  el("#detailImage").alt = p.name;
  el("#detailTitle").textContent = p.name;
  el("#detailSubtitle").textContent = p.subtitle;
  el("#detailDesc").textContent = DETAIL_SAMPLE_DESC;
  el("#detailPrice").textContent = p.priceText;

  // benefits
  const benefitsWrap = el("#detailBenefits");
  benefitsWrap.innerHTML = "";
  BENEFITS.forEach(b=>{
    const li = document.createElement("li");
    li.textContent = b.text;
    benefitsWrap.appendChild(li);
  });

  // whatsapp link with prefilled message
  const message = `Hello Bee Kiss 👋%0AI want to order:%0AProduct: ${encodeURIComponent(p.name)}%0AQuantity: ___%0ADelivery location: ___%0APlease confirm availability.`;
  // using wa.me with text param (URL-encoded)
  const waUrl = `https://wa.me/?text=${message}`;
  el("#whatsappBtn").href = waUrl;
}

function parseHash(){
  const hash = location.hash || "";
  if(hash.startsWith("#product=") || hash.includes("product=")){
    // handle both #product=id and #product=id (compat)
    const m = hash.match(/product=([^&]+)/);
    if(m && m[1]){
      showProductById(m[1]);
      return;
    }
  }
  // handle named sections
  if(hash === "#about"){
    showSection("about");
    return;
  }
  // default to catalog
  showSection("catalog");
}

function initNav(){
  el("#catalogBtn").addEventListener("click", ()=> { location.hash = ""; });
  el("#aboutBtn").addEventListener("click", ()=> { location.hash = "#about"; });
  el("#backBtn").addEventListener("click", ()=> { history.back(); });
  window.addEventListener("hashchange", parseHash);
}

function init(){
  renderCatalog();
  initNav();
  parseHash();
}

document.addEventListener("DOMContentLoaded", init);