# Bee Kiss — Premium Demo Site

This repository contains a small static website for the brand "Bee Kiss" (premium forest honey from Wayanad). It is intentionally NOT an e-commerce site: there is no cart, no checkout, and no payment gateway. Ordering is done via WhatsApp with a prefilled message.

Features
- Mobile-first, minimal, premium design (dark forest green + gold accents)
- Malayalam + English support (Noto Sans Malayalam included)
- Catalog-style product listing with compact cards
- Product detail view with Malayalam description and benefits
- WhatsApp "Order on WhatsApp" button with prefilled message
- Easy to host on GitHub Pages (pure static files)

Folder structure
- index.html — main entry
- css/styles.css — styling
- js/app.js — minimal JS (renders products, hash routing)
- assets/*.svg — small inline SVG images / logo

Deployment (GitHub Pages)
1. Create a new GitHub repository and push these files preserving the folder structure.
2. On the repository settings, enable GitHub Pages from the main branch (or gh-pages).
3. Site will be served at https://<your-username>.github.io/<repo>/ (or your custom domain).

WhatsApp prefilled message
The "Order on WhatsApp" button opens WhatsApp with the following prefilled text:

Hello Bee Kiss 👋
I want to order:
Product: {{product name}}
Quantity: ___
Delivery location: ___
Please confirm availability.

Customization ideas
- Replace SVG assets with your real product photos (keep thumbnail size small for quick load).
- Add a simple contact form (non-order) for questions.
- Connect Google Analytics or a privacy-first analytics provider.
- Add more Malayalam translations or alternate copy.

If you want, I can:
- Replace SVG placeholders with real images (you can upload them here).
- Prepare a GitHub repo with these files and push them (I will need the repo owner/name and permission).
- Add meta tags for social cards (Open Graph) with custom images.

Enjoy — Bee Kiss: സ്വാഭാവികവും വിശ്വസനീയ്യവുമായ തേൻ!